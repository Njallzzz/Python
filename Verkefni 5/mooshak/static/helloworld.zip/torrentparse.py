import os
from os.path import join
from os.path import split
from os.path import splitext

import difflib
import re
from pprint import pprint
import string

from googleapiclient.discovery import build

search_engine_results = []         # Container for all google search results to avoid repeated requests
search_avail = True

def search_engine_title(query, data):
    global search_engine_results
    global search_avail
    for result in search_engine_results:
        if re.search('{}'.format(result[0]), query):
            return result[1]

    if not search_avail:
        return False

    try:
        res = data['service'].cse().list(q=query, cx=data['engines'][data['sengine']]).execute()
    except:
        search_avail = False
        return False
    try:
        name = res['items'][0]['htmlTitle'].replace('&quot;', '').replace('&#39;', '\'')

        result = re.search('<b>([^\:\(])</b>', name, flags=re.I)
        resulttext = result.group(1).strip().replace('<b>', '').replace('</b>', '')
        
        if name:
            search_engine_results.append([query, resulttext])
            return resulttext
        else:
            print('no match using search engine: ', query, '->', name)
            return False
    except:
        search_engine_results.append([query, False])
        return False

def splitall(path):     # URL Full Directory splitter
    path_sep = []
    seperating = True
    while seperating:
        parts = split(path)
        if parts[0] == path:
            path_sep.insert(0, parts[0])
            seperating = False
        if parts[1] == path:
            path_sep.insert(0, parts[1])
            seperating = False
        else:
            path = parts[0]
            path_sep.insert(0, parts[1])
    return [ x for x in path_sep if x ]

class name_comparer:
    def __init__(self, data):
        self.data = data
        self.searched_names = []
    def compare(self, show):
        show.replace('&', 'and')
        show = show.title()

        if len(self.searched_names) and show in list(zip(*self.searched_names))[0]:
            print(show, '->', self.searched_names[ list(zip(*self.searched_names))[0].index(show) ][1])
            return self.searched_names[ list(zip(*self.searched_names))[0].index(show) ][1]
        
        if len(show) < 3:
            ratio = len(show)/4
        else:
            ratio = 0.70     # 80% name difference
        difflist = list(map(lambda x: difflib.SequenceMatcher(None, show.upper(), x.upper()).ratio(), self.data['shows']))
        diffresults = max(difflist)
        if diffresults > ratio:
            print(show, '->', self.data['shows'][difflist.index(diffresults)])
            self.searched_names.append([show, self.data['shows'][difflist.index(diffresults)]])
            return self.data['shows'][difflist.index(diffresults)]

        result = search_engine_title(show, self.data)
        if result:
            self.data['shows'].append(result)
            self.searched_names.append([show, result])
            return result
        else:
            self.data['shows'].append(show)
            self.searched_names.append([show, show])
            return show

def file_determin(data):
    data['comp'] = name_comparer(data)
    root_sep = splitall(data['input'])
    reg1 = re.compile(r'S([0-9]{1,2})E([0-9]{2,3})', flags=re.I)
    reg2 = re.compile(r'\[([0-9]{1,3})[x.]([0-9]{1,3})\]', flags=re.I)
    reg3 = re.compile(r'S([0-9]{1,2}) E ([0-9]{2,3})' , flags=re.I)
    reg4 = re.compile(r'[^0-9]([0-9]{3})[^0-9]' , flags=re.I)
    reg5 = re.compile(r'(720)p|x(264)|(720)HD|H(264)' , flags=re.I)
    reg6 = re.compile(r'([0-9]{4})' , flags=re.I)
    reg7 = re.compile(r'Season ([\w\']{1,2})[\- ]{0,2} Episode ([\w\']{1,2})' , flags=re.I)
    reg8 = re.compile(r'Season ([0-9]{1,2})[^0-9]*$' , flags=re.I)
    reg9 = re.compile(r'([0-9])([0-9]{2})' , flags=re.I)

    filelist = []
    for path, dirs, files in os.walk(data['input']):
        for file in files:
            filename, ext = splitext(file)
            
            sample = True
            if data['samples'] and re.search(r'Sample', file, flags=re.I):
                sample = False
            
            if ext in data['vid_ext'] and sample:
                path_sep = splitall(path)
                for x in root_sep:
                    path_sep.remove(x)
                if reg1.search(filename):
                    regres = reg1.search(filename)
                    filename = re.findall(r"[\w']+", filename)
                    
                    ignore = False     # For debugging
                    try:
                        showindex = filename.index(regres.group())
                        if not showindex:  # Means I need to search for the show based on directory not file
                            if len(path_sep) == 1:
                                req11res = re.search('(.*)Season ([0-9]{1,3})(.*)' , path_sep[0], flags=re.I)
                                results = list(filter(None, req11res.groups()))
                                ignore = True
                                filelist.append({'origin': join(path,file), 'name': data['comp'].compare(results[0]), 'season': regres.group(1), 'episode': regres.group(2)})
                            else:
                                showinfo = {}
                                for entry in path_sep:
                                    reg11res = re.search('Season ([0-9]{1,3})' , entry, flags=re.I)
                                    if not reg11res:
                                        showinfo['show'] = entry
                                if len(showinfo) == 1:
                                    ignore = True
                                    filelist.append({'origin': join(path,file), 'name': data['comp'].compare(showinfo['show']), 'season': regres.group(1), 'episode': regres.group(2)})
                                else:       # Show name must be in the name
                                    search_res = data['comp'].compare(' '.join(filename[1:]))
                                    if(search_res):
                                        filelist.append({'origin': join(path,file), 'name': search_res, 'season': regres.group(1), 'episode': regres.group(2)})
                                        ignore = True
                                    else:   # Unknown
                                        ignore = False
                                        filelist.append({'origin': join(path,file)})
                        else:
                            filename = '_'.join(filename).split('_')
                            showindex = filename.index(regres.group())
                            if filename[(showindex-1):showindex][0] in data['ignore']:
                                showindex = showindex - 1
                            elif re.search( r'[0-9]{4}', filename[(showindex-1):showindex][0]):
                                showindex = showindex - 1
                            ignore = True
                            filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filename[:showindex])), 'season': regres.group(1), 'episode': regres.group(2)})
                    except ValueError:      #  Multishow file
                        ignore = True
                        regres11 = None
                        for entry in filename:
                            temp = re.search(r'S([0-9]{1,3})(.*)$', entry, flags=re.I)
                            if temp:
                                regres11 = temp
                        if regres11:
                            showindex = filename.index(regres11.group())
                            filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filename[:showindex])), 'season': regres11.group(1), 'episode': regres11.group(2)})
                        else:   # Unknown
                            ignore = False
                            filelist.append({'origin': join(path,file)})
                elif reg2.search(filename):
                    regres = reg2.search(filename)
                    filename = re.findall(r"[\w']+", filename.replace('.', 'x'))
                    showindex = filename.index('{}x{}'.format(regres.group(1), regres.group(2)))
                    filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filename[:showindex])), 'season': regres.group(1), 'episode': regres.group(2)})
                    ignore = True
                elif reg3.search(filename):
                    regres = reg3.search(filename)
                    filename = re.findall(r"[\w']+", filename.replace('.', 'x'))
                    showindex = filename.index('S{}'.format(regres.group(1)))
                    filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filename[:showindex])), 'season': regres.group(1), 'episode': regres.group(2)})
                    ignore = True
                elif reg4.search(filename):
                    regres = reg4.search(filename)
                    compres = reg5.search(filename)
                    showlist = re.search(r'([0-9])([0-9]{2})', regres.group(1)).groups()
                    if not compres:
                        filename = re.findall(r"[\w']+", filename)
                        try:
                            showindex = filename.index(regres.group(1))
                            filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filename[:showindex])), 'season': showlist[0], 'episode': showlist[1]})
                            ignore = True
                        except ValueError:
                            filelist.append({'origin': join(path,file)})
                            ignore = True
                    else:
                        if not any([ regres.group(1) == x for x in compres.groups() ]):
                            filename = re.findall(r"[\w']+", filename)
                            showindex = filename.index(regres.group(1))
                            filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filename[:showindex])), 'season': showlist[0], 'episode': showlist[1]})
                            ignore = True
                        else:
                            if re.search(r'[0-9]{1,2}x[0-9]{1,2}', filename):
                                regres = re.search('([0-9]{1,2})x([0-9]{1,2})', filename)
                                filenamelis = re.findall(r"[\w']+", filename)   
                                
                                showindex = filenamelis.index(regres.group())
                                showname = ' '.join(filenamelis[:showindex]).split('_')
                                for i, x in enumerate(showname.copy()):
                                    if re.search('[0-9]{4}', x):
                                        del showname[i]
                                filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(showname)), 'season': regres.group(1), 'episode': regres.group(2)})
                                ignore = True
                            else:
                                filelist.append({'origin': join(path,file)})
                                ignore = True
                elif reg6.search(filename):
                    regres = reg6.search(filename)
                    if (int(regres.group(1)) > 1930 and int(regres.group(1)) < 2150) or int(regres.group(1)) == 1080:
                        filelist.append({'origin': join(path,file)})
                        ignore = True
                    else:
                        filenamelis = re.findall(r"[\w\-']+", filename)
                        regres = None
                        for x in filenamelis:
                            temp = re.search(r'^([0-9]{2})([0-9]{2})$', x)
                            if temp:
                                regres = temp
                        try:
                            ignore = True
                            showindex = filenamelis.index(regres.group())
                            filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filenamelis[:showindex])), 'season': regres.group(1), 'episode': regres.group(2)})
                        except AttributeError:  # Multishow file
                            regres = None
                            for x in filenamelis:
                                temp = re.search(r'^([0-9]{2})([0-9]{2})-([0-9]{2})$', x)
                                if temp:
                                    regres = temp
                            showindex = filenamelis.index(regres.group())
                            filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filenamelis[:showindex])), 'season': regres.group(1), 'episode': 'E{}E{}'.format(regres.group(2), regres.group(3))})
                            ignore = True
                elif reg7.search(filename):
                    regres = reg7.search(filename)
                    filenamelis = re.findall(r"[\w']+", filename)
                    showindex = filenamelis.index('Season')
                    if not regres.group(1).isdigit():
                        series = string.ascii_uppercase.index(regres.group(1)) + 1
                    else:
                        series = regres.group(1)
                    filelist.append({'origin': join(path,file), 'name': data['comp'].compare(' '.join(filenamelis[:showindex])), 'season': series, 'episode': regres.group(2)})
                    ignore = True
                elif any(list(map(lambda x: reg8.search(x), path_sep))):
                    season = max(list(map(lambda x: reg8.search(x).group(1) if reg8.search(x) else '', path_sep)))  # Er rett season
                    show = None
                    if len(path_sep) > 1:
                        for x in path_sep[::-1]:
                            if re.search('(.+) Season ', x, flags=re.I):
                                regres1 = re.search('(.+) Season ', x, flags=re.I)
                                show = re.sub('[\(\[].*?[\)\]]', '', regres1.group(1))
                                show = re.sub('Season', '', show).strip()
                            elif not re.search('Season {}'.format(season),x):
                                show = re.sub('[\(\[].*?[\)\]]', '', x)
                                show = re.sub('Season', '', show).strip()
                    else:
                        path_sep_words = re.findall(r"[\w']+", path_sep[0])
                        showindex = path_sep_words.index('Season')
                        show = ' '.join(path_sep_words[:showindex])
                    episode = None
                    if len(path_sep) > 1:
                        if re.search(r'Episode ([0-9]{1,2})', filename, flags=re.I):
                            episode = re.search(r'Episode ([0-9]{1,2})', filename, flags=re.I).group(1)
                        elif re.search(r'[0-9]{1,2}x([0-9]{1,2})', filename, flags=re.I):
                            episode = re.search(r'[0-9]{1,2}x([0-9]{1,2})', filename, flags=re.I).group(1)
                        elif re.search(r'E([0-9]{1,2})', filename, flags=re.I):
                            episode = re.search(r'E([0-9]{1,2})', filename, flags=re.I).group(1)
                        elif re.search(r'[0-9]([0-9]{2}[a&b]*)', filename, flags=re.I):
                            episode = re.search(r'[0-9]([0-9]{2}[a&b]*)', filename, flags=re.I).group(1)
                            if not episode.isdigit():
                                episode = episode.upper()
                        elif re.search(r'([0-9]{1,2})', filename, flags=re.I):
                            episode = re.search(r'([0-9]{1,2})', filename, flags=re.I).group(1)
                    else:
                        if re.search(r'[0-9]{1,2}x[0-9]{1,2}', filename, flags=re.I):
                            episode = re.search(r'[0-9]{1,2}x([0-9]{1,2})', filename, flags=re.I).group(1)
                        else:
                            episode = re.search(r'\- ([0-9]{1,2}) \-', filename, flags=re.I).group(1)
                    if show and episode:
                        filelist.append({'origin': join(path,file), 'name': data['comp'].compare(show), 'season': season, 'episode': episode})
                    else:
                        filelist.append({'origin': join(path,file)})
                    ignore = True

                elif reg9.search(filename) and len(path_sep) > 1:
                    season, episode = reg9.search(filename).groups()
                    show = data['comp'].compare(path_sep[0])
                    
                    ignore = True
                    filelist.append({'origin': join(path,file), 'name': show, 'season': season, 'episode': episode})
                else:
                    ignore = True
                    filelist.append({'origin': join(path,file)})
                        
                if not ignore:
                    print(path, filename, ext)     

    return filelist
            
