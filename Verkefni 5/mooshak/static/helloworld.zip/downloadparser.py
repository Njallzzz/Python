import os
from os.path import join
from os.path import exists
from os.path import splitext
import shutil
import re
import configparser
import http.client

from pprint import pprint

from googleapiclient.discovery import build
from torrentparse import file_determin
from torrentparse import splitall

import argparse

def get_eztv_shows(override):
    conn = http.client.HTTPSConnection("eztv.ag", 443)
    r1 = conn.request('GET','/showlist/')
    r1 = conn.getresponse()
    if r1.status != 200:
        print(r1.status, r1.reason)
        return None
    showlist = []
    data = r1.read().decode('UTF-8')
    for lis in data.splitlines():
        if re.search( r'<td class="forum_thread_post"><a href', lis):
            mat = re.search(r'link">([^<]*)</a></td>', lis)
            if mat.group(1).lower() in override.keys():
                showlist.append(override[mat.group(1).lower()])
            else:
                result = mat.group(1).split('(')
                result = list(filter(None, result))
                if len(result) == 2:
                    result = '{} {}'.format(result[0], result[1].split(')')[1])
                else:
                    result = result[0]
                result = result.replace(':', '').split(',')
                if len(result) == 2:
                    result = '{} {}'.format(result[1].strip(), result[0].strip())
                    showlist.append(result.strip())
                else:
                    showlist.append(result[0].strip())
    return showlist

def move_shows(data, lis):
    inputdir = splitall(data['input'])

    errorlogs = []
    for entry in lis:
        if any(list(map(lambda x: 'name' == x, entry.keys()))):     # Known
            path = join(join(data['output'], entry['name']), 'Season {}'.format(int(entry['season'])))
            try:
                os.makedirs(path)
            except FileExistsError:
                pass
            filename, ext = splitext(splitall(entry['origin'])[-1])
            if entry['episode'].isdigit():
                path = join(path, 'S{}E{}{}'.format(entry['season'], entry['episode'], ext) )
            else:
                path = join(path, 'S{}{}{}'.format(entry['season'], entry['episode'], ext) )
            if data['delete']:
                try:
                    shutil.move(entry['origin'], path)
                except:
                    errorlogs.append(['Unable to move file', entry['origin'], path])
            else:
                try:
                    shutil.copy2(entry['origin'], path)
                except:
                    try:
                        shutil.copy(entry['origin'], path)
                    except:
                        errorlogs.append(['Unable to move file', entry['origin'], path])
            
        else:   # Unknown
            path_sep = splitall(entry['origin'])
            for x in inputdir:
                path_sep.remove(x)
            path_sep = path_sep[:-1]
            path = data['unknown']
            for subdir in path_sep:
                path = join(path, subdir)
            try:
                os.makedirs(path)
            except FileExistsError:
                pass
            filename = splitall(entry['origin'])[-1]
            path = join(path, filename)
            if data['delete']:
                try:
                    shutil.move(entry['origin'], path)
                except:
                    errorlogs.append(['Unable to move file', entry['origin'], path])
            else:
                try:
                    shutil.copy2(entry['origin'], path)
                except:
                    try:
                        shutil.copy(entry['origin'], path)
                    except:
                        errorlogs.append(['Unable to move file', entry['origin'], path])
    return errorlogs

class Shell:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read('config.ini')
        self.reference_show_override = {}
        self.search_engines = {}
        self.reference_show_additions = []
        self.recur_del = False
        self.ignore_samples = True

        self.cwd = os.path.dirname(os.path.realpath(__file__))
        self.input = join(self.cwd, self.config['main']['input'])
        if not exists(self.input):
            print('The default input directory doesn\'t exist, please specify via the command \'set input\'')
            self.input = ''
        self.output = join(self.cwd, self.config['main']['output'])
        self.unknown = join(self.cwd, self.config['main']['unknown'])
        
        self.video_file_ref = self.config['main']['video_files'].split(',')
        self.ignore_end_words = self.config['main']['ignore_words'].split(',')
        self.selected_engine = self.config['main']['default_search_engine']

        self.search_service = build('customsearch', 'v1', developerKey=self.config['googleapi']['api'])
        if not self.search_service:
            print('Unable to create valid Google API service, this will limit the parsers ability to parse certain files')

        for entry in self.config['searchengines']:
            self.search_engines[entry] = self.config['searchengines'][entry]

        for entry in self.config['eztvparseroverride']:
            self.reference_show_override[entry] = self.config['eztvparseroverride'][entry]

        self.known_shows = get_eztv_shows(self.reference_show_override)
        if not self.known_shows:
            print('Unable to retrieve showlist from eztv.ag, this will limit the parsers ability to parse certain files')

        with open('showoverride.txt', encoding='UTF-8') as cf:
            for entry in cf.read().splitlines():
                self.known_shows.append(entry)
  
        self.welcome()
        self.info()
        while True:
            inp = input('DownloadParser>')
            try:
                inp = inp.split(' ')
                if len(inp) == 1:
                    getattr(self, inp[0])()
                else:
                    getattr(self, inp[0])(*inp[1:])
            except AttributeError:
                print('Invalid command, type help for information')
    def welcome(self):
        print('DownloadParser is a file parser that will structure movies and shows')
        print('type \'help\' for a list of commands')
        
    def info(self):
        print('Input: {} (Directory to search)\nOutput: {} (Directory to insert structured)\nUnknown: {} (Directory for unknown)'.format(self.input, self.output, self.unknown))
        print('Selected search engine: {} (engines for list of search engines)'.format(self.selected_engine))
        print('Recursive deletion of the input directory:', self.recur_del)

    def engines(self):
        print('Available search engines: {}'.format(', '.join(self.search_engines)))

    def set(self, *args):
        if len(args) < 1:
            print('Syntax: set (engine, deletion, input, output, unknown) (argument)')
            return
        if args[0] == 'engine':
            if len(args) < 2:
                print('Syntax: set engine ({})'.format(', '.join(self.search_engines)))
                return
            if not args[1] in self.search_engines:
                print('Invalid parameter, please provide a valid search engine')
            else:
                self.selected_engine = args[1]
                print('Selected search engine: {}'.format(self.selected_engine))
        if args[0] == 'deletion':
            if len(args) < 2:
                print('Syntax: set deletion (True, False)')
                return
            if not args[1] in ['False', 'True']:
                print('Invalid parameter, please provide a valid search engine')
            else:
                self.recur_del = args[1] == 'True'
                print('Recursive deletion of the input directory:', self.recur_del)
        elif args[0] in ['input', 'output', 'unknown']:
            newpath = input('Absolute path: ')
            if args[0] == 'input':
                if exists(newpath):
                    self.input = newpath
                else:
                    print('Invalid path:', newpath)
            elif args[0] == 'output':
                self.output = newpath
            elif args[0] == 'unknown':
                self.unknown = newpath
            
        else:
            print('Syntax: set (engine, deletion, input, output, unknown) (argument)')

    def shows(self, name=None):
        if not name:
            print('Total shows in database: {}\nSyntax: shows (name of show)'.format(len(self.known_shows)))
        else:
            for entry in self.known_shows:
                if re.match('^{}'.format(name), entry, flags=re.I):
                    print('Found show:', entry)

    def filetypes(self):
        print('Video file extensions: {}'.format(', '.join(self.video_file_ref)))

    def add(self, *args):
        if len(args) < 2:
            print('Syntax: add (video, show) (arguments)')
            return
        if args[0] == 'video':
            for entry in args[1:]:
                if not entry[0] == '.':
                    print('Invalid video file extension:', entry)
                elif entry in self.video_file_ref:
                    print(entry, 'is already a handled file extension')
                else:
                    self.video_file_ref.append(entry)
        elif args[0] == 'show':
            for entry in args[1:]:
                if entry in self.known_shows:
                    print('Show', entry, 'already in the database')
                else:
                    self.known_shows.append(entry)
        else:
            print('Syntax: add (video, show) (arguments)')

    def delete(self, *args):
        if len(args) < 2:
            print('Syntax: delete (video, show) (arguments)')
            return
        if args[0] == 'video':
            for entry in args[1:]:
                if entry in self.video_file_ref:
                    self.video_file_ref.remove(entry)
                else:
                    print(entry, 'is not a video file extension')
        elif args[0] == 'show':
            for entry in args[1:]:
                if entry in self.known_shows:
                    self.known_shows.remove(entry)
                else:
                    print(entry, 'is not in the database')
        else:
            print('Syntax: delete (video, show) (arguments)')
        
    def help(self):
        commands = [method for method in dir(self) if callable(getattr(self, method)) and not method.startswith('_')]
        print('Available commands: {}'.format(', '.join(commands)))

    def execute(self):
        if self.input == '':
            print('Please specify the input directory via the command \'set input\'')
            return
        inputdict = {}
        outputdict = {}
        inputdict['input'] = self.input
        inputdict['shows'] = self.known_shows
        inputdict['ignore'] = self.ignore_end_words
        inputdict['vid_ext'] = self.video_file_ref
        inputdict['service'] = self.search_service
        inputdict['sengine'] = self.selected_engine
        inputdict['engines'] = self.search_engines
        inputdict['samples'] = self.ignore_samples
        lis = file_determin(inputdict)

        outputdict['input'] = self.input
        outputdict['output'] = self.output
        outputdict['unknown'] = self.unknown
        outputdict['delete'] = self.recur_del
        errorlogs = move_shows(outputdict, lis)

        for entry in errorlogs:
            print('ERROR: {}\nOrigin: {}\nTarget: {}'.format(entry[0], entry[1], entry[2]))
        print('Finished Execution\n\'exit\' to close the shell')
        
    def exit(self):
        quit(0)
        
    def quit(self):
        quit(0)

def main():
    sh = Shell()

if __name__ == '__main__':
  main()
