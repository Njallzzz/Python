#include <iostream>

// User input
#include "myclass.h"

using namespace std;

int main() {
	myClass test;
	cout << test.there() << endl;
	return 0;
}