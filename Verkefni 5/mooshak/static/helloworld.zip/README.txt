﻿Til að keyra forrit þarf að keyra skrána downloadparser.py
torrentparse.py er eingöngu með hluti sem downloadparser.py notar í gegnum import
Notar Python3

Allir þættir sem eru sóttir til röðunar eru frá input directory
Allir þættir eru settir í directory sem mun hér með vera output
Öll skjöl sem ekki er hægt að raða fara undir unknown directory

Til að sæka allt sem þarf til að keyra forritið þarf að keyra í Windows eða viðeigandi í Linux:
py -m pip -r pip-requirements.txt

Þegar forritið er keyrt upp leitar það á eztv.ag að þáttalistanum þeirra og bætir síðan við þeim
þáttum sem eru í showoverride.txt. Það er vegna þess eztv.ag er ekki með alla erlenda og enga
íslenska þætti.

downloads mappan er með innihaldið á upprunalegu downloads.zip skránni í verkefninu.

ýmsar grunnstillingar eru til staðar í config.ini

Ýmsar skipanir sem gott er að vita af:
info		// Sýnir hvaða input, output og unknown directory forritið er að nota á stundinni
		// ásamt annara almennra upplýsinga

help		// Sýnir allar skipanir sem hægt er að nota

execute		// Framkvæmir sorting á þáttum, ekki hægt að afturkalla eftir köllun

set		// Til að setja ýmsar stillingar á parserinum

set deletion 	// Til að virkja eða slökkva á eyðingu á fluttum skrám frá input directory
Dæmi: set deletion True eða set deletion False

set engine	// Til að velja leitarvél sem er hægt að sjá með ´engines´ (ekki breyta frá imdb)
Dæmi: set engine imdb

set input	// Til að setja input directory fyrir downloadparser
Dæmi: set input

set output	// Til að setja output directory fyrir downloadparser
Dæmi: set output

set unknown	// Til að setja unknown directory fyrir downloadparser
Dæmi: set unknown

filetypes	// Sýnir allar skjalatýpir sem eru höndlaðar

shows		// Sýnir númer þátta í gagnagrunni á forriti, einnig hægt að leita að þátt
Dæmi:	shows da

// Meira...

TL;DR: python -m pip install -r pip-requirements.txt, keyra downloadparser.py og skrifa 'execute' í terminal til að keyra